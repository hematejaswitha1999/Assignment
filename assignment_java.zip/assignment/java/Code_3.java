package assignment.java;

public class Code_3 {
	public static void main(String args[]) {
		String str="radar";
		String rev="";
		int length=str.length();
		for(int i=length-1;i>=0;i--) {
			rev=rev+str.charAt(i);
		}
		if (str.toLowerCase().equals(rev.toLowerCase())) {
			System.out.println("palindrome");
		}
		else {
			System.out.println("not a palindrome");
		}

	}
}
