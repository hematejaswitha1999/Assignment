package assignment.java;

public class Code_7 {
public static void main(String[] args) {
	char C = 'S';
	String s=Character.toString(C);
	System.out.println("string " + s);
	
	String S="haihai";  
	for(int i=0; i<S.length();i++){  
	        char c = S.charAt(i);  
	        System.out.println("char at "+i+" index is: "+c);  
	}   
}
}


