package assignment.java;

import java.util.Scanner;

public class Code_26 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String inputString;

		System.out.println("Enter a string :");
		inputString = sc.nextLine();

		
		System.out.println("Following numbers are found: ");

		for (char ch : inputString.toCharArray()) {
			if (Character.isDigit(ch)) {
				System.out.print(ch + " ");
			}
		}
	}}
