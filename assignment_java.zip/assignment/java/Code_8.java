package assignment.java;

public class Code_8 {
public static void main(String[] args) {
	int[] arr= {1,3,5,7,9};
	int num=1;
	for( int i=0;i<arr.length;i++)
		if(num==arr[i]) {
			System.out.println("value found");
		}
	}

}
