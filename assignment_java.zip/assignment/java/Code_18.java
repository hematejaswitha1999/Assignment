package assignment.java;

public class Code_18 {

	public static void main(String[] args) {
		String sen = "We are all Friends Forever";
		int vowels = 0, consonants = 0;

		sen = sen.toLowerCase();
		for (int i = 0; i < sen.length(); ++i) {
			char ch = sen.charAt(i);

			if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
				++vowels;
			}

			else if ((ch >= 'a' && ch <= 'z')) {
				++consonants;
			}
		}
		System.out.println("vowels " + vowels);
		System.out.println("consonants " + consonants);
	}
}
