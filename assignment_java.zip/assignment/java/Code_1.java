package assignment.java;

import java.util.Scanner;

public class Code_1 {
	public static void  main(String[] args)
	{
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the number");
		int n=scanner.nextInt();
		boolean flag=false;
		for(int i=2;i<=n/2;i++) {
			if (n%i==0) {
				flag=true;
			}
		}
		if(!flag)
			System.out.println("Prime number");
		else {
			System.out.println("not a prime number");
		}
	}
}

