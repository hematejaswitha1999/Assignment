package assignment.java;

import java.util.ArrayList;

public class Code_10 {
	 public static void main(String args[]){
	      ArrayList<String> list1 = new ArrayList<String>();
	      list1.add("kolkata");
	      list1.add("Banglore");
	      list1.add("hyderabad");
	      System.out.println("Contents of list1 :"+list1);

	      ArrayList<String> list2 = new ArrayList<String>();
	      list2.add("visakhapatnam");
	      list2.add("chennai");
	      list2.add("kerala");
	      System.out.println("Contents of list2 :"+list2);

	      list1.addAll(list2);
	      System.out.println("Contents after adding "+list1);
	   }
	}
