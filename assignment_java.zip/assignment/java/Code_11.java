package assignment.java;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Code_11 {
	  public static void main(String[] args) {  
	        
	        List<String> List = new ArrayList<>();  
	        
	        List.add("A");  
	        List.add("B");  
	        List.add("C");  
	        List.add("D");  
	        List.add("E");  
	        System.out.println(" ArrayList to Array" );  
	        String[] item = List.toArray(new String[List.size()]);  
	        for(String s : item){  
	            System.out.println(s);  
	        }  
	        System.out.println(" Array to ArrayList" );  
	        List<String>list2 = new ArrayList<>();  
	        list2 =  Arrays.asList(item);  
	        System.out.println(list2);  
	    }  
	}  
