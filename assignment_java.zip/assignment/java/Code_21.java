package assignment.java;

import java.util.Scanner;

public class Code_21 {
	public static void main(String args[]) {

		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the number");
		int n=scanner.nextInt();
		if(n%2==0) {
			System.out.println("the number is even");
		}
		else {
			System.out.println("the number is odd");
		}
	}
}
