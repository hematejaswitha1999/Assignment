package assignment.java;

public class Code_22 {
	public static void main(String args[]) {
		String str = "He is Studying engineering 3rd year";
		char ch = 'e';
		int frequency = 0;

		for(int i = 0; i < str.length(); i++) {
			if(ch == str.charAt(i)) {
				++frequency;
			}
		}

		System.out.println("Frequency of " + ch + " = " + frequency);
	}
}
