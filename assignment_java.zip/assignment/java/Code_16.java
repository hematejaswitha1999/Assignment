package assignment.java;

public class Code_16 {
public static void main(String args[]) {
	int num=6;
	for(int i =1;i<=10;i++) {
		System.out.printf("%d * %d = %d \n", num, i, num * i);
	}
}
}
