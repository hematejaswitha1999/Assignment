package assignment.java;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Code_23 {
	  public static void main(String[] args)
	     {
	        String string = "2022-05-25";
	        LocalDate date = LocalDate.parse(string, DateTimeFormatter.ISO_DATE);

	        System.out.println(date);
	    }
}
