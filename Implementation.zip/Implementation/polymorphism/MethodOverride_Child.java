package polymorphism;

public class MethodOverride_Child extends MethodOverride_Parent {
	int seatHeight;
	
MethodOverride_Child(int speed,int seatHeight) {
		super(speed);
	}
@Override
int applyBrake(int dec ) {
	return speed-=dec +10;
}
@Override
int speedUp(int inc) {
	return speed-=inc-5;
}
public static void main(String args[]) {
	MethodOverride_Parent m1=new MethodOverride_Parent(40);
	System.out.println("the speed after break " +m1.applyBrake(5));
	MethodOverride_Parent m2=new MethodOverride_Child(50, 90);
	System.out.println("the speed of after break" +m2.applyBrake(10));
	
}
}
