package polymorphism;

public class MethodOverloading {
public int multiply(int a,int b) {
	return a*b;
	
	}
public double multiply(double a,double b) {
	return a*b;
	}
public int multiply(int a,int b,int c) {
	return a*b*c;
	}
public static void main(String args[]) {
	MethodOverloading m1=new MethodOverloading();
	System.out.println(m1.multiply(2, 6));
	System.out.println(m1.multiply(2, 3, 9));
	System.out.println(m1.multiply(30.9, 45.6));
}
}
