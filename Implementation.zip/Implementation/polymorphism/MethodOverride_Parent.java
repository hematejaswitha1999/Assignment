package polymorphism;

public class MethodOverride_Parent {
 static int  speed;
  MethodOverride_Parent(int speed){
  this.speed=speed; 
 }
  
int applyBrake(int dec ) {
	return speed-=dec;
}
int speedUp(int inc) {
	return speed-=inc;
}
}
