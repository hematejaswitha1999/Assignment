package strings;

public class StringBuffer_1 {
	public static void main(String[] args) {
		
		StringBuffer str= new StringBuffer("Priyanka");
		 
		System.out.println(str.capacity());
		System.out.println(str.charAt(6));
		System.out.println(str.codePointAt(0));    
		System.out.println(str.substring(0, 2));   
		System.out.println(str.length());

		System.out.println(str.reverse()); 
	}
}
