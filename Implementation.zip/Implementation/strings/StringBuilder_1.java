package strings;

public class StringBuilder_1 {

	public static void main(String[] args) 
	{
		StringBuilder st = new StringBuilder("Make");
		System.out.println(st.capacity());
		StringBuilder str=st.append("your self strong");
		System.out.println(str);
		System.out.println(st.reverse());
		

}
}