package strings;

public class String_1 {
	public static void main(String args[]) {
		String str="happy news";
		String str1=" waiting";
		String rev="";
		int length=str.length();
		for(int i=length-1;i>=0;i--) {
			rev=rev+str.charAt(i);
		}
			System.out.println(rev);
			System.out.println(str.concat(str1)); 
			System.out.println(str.trim()); 
			System.out.println(str.endsWith("!"));
			System.out.println(str.substring(4));
			System.out.println(str1.length());
		}
	}
