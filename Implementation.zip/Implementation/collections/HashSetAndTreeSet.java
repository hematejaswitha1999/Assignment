package collections;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class HashSetAndTreeSet {
public static void main(String args[]) {
	Set<String> hashset = new HashSet<>(5);
	hashset.add("A");
	hashset.add("B");
	boolean r1=hashset.add("C");
	System.out.println(r1);
	boolean r2=hashset.add("C");
	System.out.println(r2);
	System.out.println(hashset);
	boolean r3= hashset.contains("A");
	System.out.println(r3);
	for(String item:hashset) {
		System.out.println(item);
	}
	
	Set<String> treeset = new TreeSet<>();
	treeset.add("B");
	treeset.add("C");
	treeset.add("A");
	treeset.add("D");
	System.out.println(treeset);
	
}
}
