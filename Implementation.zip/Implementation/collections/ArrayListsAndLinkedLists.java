package collections;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ArrayListsAndLinkedLists {
	public static void main(String args[]) {
		List<Integer> arraylist = new ArrayList<Integer>(5);
		for( int i=0; i<5; i++) {
			arraylist.add(i);

		}
		System.out.println(arraylist);
		arraylist.remove(4);
		System.out.println(arraylist);

		for(int i : arraylist) {
			System.out.print(i+ " ");
		}
		for (int i=0 ; i<arraylist.size(); i++) {
			System.out.println(arraylist.get(i)+ " ");
		}
		List<String> linkedlist = new LinkedList<String>();
		linkedlist.add("A");
		linkedlist.add("B");
		linkedlist.remove(0);
		linkedlist.add(0, "c");
		System.out.println(linkedlist);
		
	}
}
