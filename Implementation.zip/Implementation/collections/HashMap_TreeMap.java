package collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class HashMap_TreeMap {
	public static void main(String args[]) {
		Map<String,Integer> hashmap=new HashMap<>();
		hashmap.put("a", 1);
		hashmap.put("c", 2);
		hashmap.put("d" ,3);
		System.out.println(hashmap);
		hashmap.remove("d");
		for( Entry<String, Integer> entry: hashmap.entrySet()) {
			System.out.println(entry.getKey() + entry.getValue());

		}
		Map<String,Integer> treemap=new TreeMap<>();
		treemap.put("a", 1);
		treemap.put("c", 2);
		treemap.put("b" ,3);
		System.out.println(treemap);
		treemap.remove("c");

	}
}