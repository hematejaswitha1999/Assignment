package collections;

import java.util.PriorityQueue;

import java.util.Stack;

public class StackAndQueue {
public static void main(String args[]) {
	Stack<String> stack= new Stack<>();
	stack.push("ram");
	stack.push("raj");
	stack.push("ravi");
	System.out.println(stack);
	System.out.println(stack.pop());
	System.out.println(stack.peek());

  PriorityQueue<String> queue =new PriorityQueue<String>();
  queue.add("ass");
  queue.add("rass");
  queue.add("lass");
  System.out.println(queue);
  System.out.println(queue.remove());
  System.out.println(queue.poll());
  System.out.println(queue);
}
}
