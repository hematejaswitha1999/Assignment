package accessModifiers;

public class Public_Private_Protected {
	private int num1;
public void display_1() {
	System.out.println("visible to the world");
}
 void display_2() {
	System.out.println("visible to the package");
}
protected void display_3() {
		System.out.println("visible to the subclasses");
	}
public static void main(String args[]) {
	Public_Private_Protected p1=new Public_Private_Protected ();
	p1.num1=23;
	p1.display_1();
	p1.display_2();
	p1.display_3();
}
}
