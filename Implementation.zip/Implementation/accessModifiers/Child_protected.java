package accessModifiers;

public class Child_protected extends Public_Private_Protected{
	public static void main(String args[]) {
	Child_protected p2 =new Child_protected();
	p2.display_1();
	p2.display_2();
	p2.display_3();
	//p2.num1=4;
}
}