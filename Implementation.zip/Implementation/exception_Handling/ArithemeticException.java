package exception_Handling;

public class ArithemeticException {

	public static void main(String[] args) {

		int a=10;
		System.out.println(a);
		try{
			int result= a/0;
			System.out.println(result);
		}catch(ArithmeticException ex){
			ex.printStackTrace();
		}
		System.out.println("program ends");
	}
}
