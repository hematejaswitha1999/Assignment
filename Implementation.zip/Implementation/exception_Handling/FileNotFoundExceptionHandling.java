package exception_Handling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileNotFoundExceptionHandling {
	public static void main(String[] args) throws IOException {
		System.out.println("Program starts");
		try {
			FileInputStream File= new FileInputStream("C:\\Users\\Hemalatha\\eclipse-practice\\TrainingAssignmentJava\\src\\exceptionHandling");
		} catch (FileNotFoundException e) {
		System.out.println(e);
			}
		System.out.println("Program ends");
	}
}
