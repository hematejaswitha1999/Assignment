package exception_Handling;

public class ArrayOutOfBound {
	  public static void main(String[] args) {
			int[] array= {23,30,20,34,28};
			int a= array.length;
			System.out.println(a);
			int b= array[4];
			try {
				System.out.println(array[7]);
			}catch(ArrayIndexOutOfBoundsException ex) {
				System.out.println(ex);
			}finally {
				System.out.println("Finally block always executes");
			}
			 
	  }
}
