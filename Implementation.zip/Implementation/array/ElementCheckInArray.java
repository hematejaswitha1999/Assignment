package array;

import java.util.Scanner;

public class ElementCheckInArray {
	 {
	
	}
	public static void main(String args[]) {
		check();
		}
			static   void check() {
				Scanner input=new Scanner(System.in);
				
				int[] array=new int [10];
				System.out.println("enter  array");
				for(int i=0;i<10;i++) {
				array[i]=input.nextInt();
				}
				for(int i=0;i<10;i++) {
					System.out.println(array[i]);
					
				}
				{
		System.out.println("enter  element to check");
		int n=input.nextInt(); 
			for(int i=0;i<10;i++) {
			
		if(array[i]==n) {
			System.out.println("integer present");}}
		
			}
			}
}
