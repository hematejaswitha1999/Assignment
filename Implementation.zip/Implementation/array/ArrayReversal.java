package array;

public class ArrayReversal {
	public static void main(String[] args) {  
         
        int [] arr = new int [] {3,4,8,5,9};  
        System.out.println("Original array: ");  
        for (int i = 0; i < arr.length; i++) {  
            System.out.print(arr[i] + " ");  
        }  
        System.out.println();  
        System.out.println(" reversal array: ");  
        
        for (int i = arr.length-1; i >= 0; i--) {  
            System.out.print(arr[i] + " ");  
           }
	}
}
