package constructors;

public class Student_ParameterisedConstructor {
int roll_no;
String name;
Student_ParameterisedConstructor(int roll_no,String name){
	this.roll_no=roll_no;
	this.name=name;
	}
Student_ParameterisedConstructor(int roll_no){
	this.roll_no=roll_no;
	this.name="unknown";
}

void display() {
	System.out.println("name of student:"+this.name+"\n"+"roll no:"+this.roll_no);
}
public static void main(String args[]) {
	Student_ParameterisedConstructor a=new Student_ParameterisedConstructor(111,"kiran");
	Student_ParameterisedConstructor b=new Student_ParameterisedConstructor(12);
	a.display();
	b.display();
}
}
