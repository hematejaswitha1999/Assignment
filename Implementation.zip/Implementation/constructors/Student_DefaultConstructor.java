package constructors;

public class Student_DefaultConstructor {
String name;
int roll_no;
Student_DefaultConstructor(String name)
{
this.name=name;
}
Student_DefaultConstructor(){
	this.name="unknown";
}
public static void main(String args[])
{ 
	Student_DefaultConstructor john=new Student_DefaultConstructor("john");
	john.roll_no=2;
	Student_DefaultConstructor a=new Student_DefaultConstructor();
	john.display();
	a.display();
}
void display() {
	System.out.println("name of the student is "+this.name+"\n"+"roll no is "+this.roll_no );
}
}
