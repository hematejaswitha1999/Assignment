package typeConversion;

public class DataConversion {
	public static void main(String args[]) {
//Downcasting
		int a=10;
		System.out.println(a);
		long b=a;
		System.out.println(b);
		float c=b;
		System.out.println(c);
//Upcasting
		double d=34.23;
		System.out.println(d);
		float f=(float)d;
		System.out.println(f);
		int i=(int)f;
		System.out.println(i);
	}
}
