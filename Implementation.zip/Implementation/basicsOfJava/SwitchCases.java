package basicsOfJava;

public class SwitchCases {
	public static void main(String[] args) {
		int week_day=7;
		switch(week_day) {
		case 1:
			System.out.println("Sunday");
			break;
			
		case 2:
			System.out.println("Monday");
			break;

		case 3:
			System.out.println("Tuesday");
			break;

		case 4:
			System.out.println("Wednesday");
			break;

		case 5:
			System.out.println("thursday");
			break;

		case 6:
			System.out.println("Friday");
			break;

		case 7:
			System.out.println("saturday");
			break;
			
	    default:
	    	System.out.println("Invalid week_day");
	    	break;

		}
	}
}