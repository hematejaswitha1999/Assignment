package basicsOfJava;

public class WhileLoop {
public static void main(String args[]) {
	char ch='A';
	while(ch<='Z') {
		System.out.print(" " +ch);
		ch++;
	}
}
}
