package basicsOfJava;

public class ForLoop {

	public static void main(String args[]) {

		int sum=0;
		int n=100;
		for(int i=n;i>=1;--i) {
			sum+=i;
			}
		System.out.println("sum of natural numbers=" + sum);
		}
	}