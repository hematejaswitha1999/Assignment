package basicsOfJava;

public class VariablesAndDatatypes {
static int num1=10;
int num2;
public int add() {
	int sum;
	num2=20;
	sum=num1+num2;
	System.out.println(sum);
	return sum;
	
}
public static void main(String args[]) {
	int n=23;
	float f=67.87f;
	double d=79.0976543d;
	long l=6325954540975l;
	char ch='h';
	boolean b=true;
	String s="USA";
	System.out.println("  int =" + n + " float =" + f+ " double =" +d + " long= "+ l+ " char= " + ch + " " +num1);
	System.out.println(!b);
	System.out.println(s);
	VariablesAndDatatypes v= new VariablesAndDatatypes();
	v.add(); 
}
}
