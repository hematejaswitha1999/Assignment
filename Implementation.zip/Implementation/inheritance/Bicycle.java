package inheritance;

public class Bicycle extends Vehicle {
public static void main(String args[]) {
	Bicycle b=new Bicycle() ;
	b.NoOfWheels=2;
	b.model="Moutain bike";
	b.display();
	b.getModel();
	b.setModel("BMX bike");
	b.display();
}
}

