package inheritance;

public class Vehicle {
	int speedrange;
	int NoOfWheels; 
	String model;
	public void vehicle(int speedrange,int NoOfWheels,String model) {
		this.speedrange=speedrange;
		this.NoOfWheels=NoOfWheels;
		this.model=model;
	}
	public int getSpeedrange() {
		return speedrange;
	}
	public void setSpeedrange(int speedrange) {
		this.speedrange = speedrange;
	}
	public int getNoOfWheels() {
		return NoOfWheels;
	}
	public void setNoOfWheels(int noOfWheels) {
		NoOfWheels = noOfWheels;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public void display() {
		System.out.println(this.model + " noOfWheels "+ this.NoOfWheels + " speed range "+ this.speedrange);
	}
}