package abstractionAndEncapsulation;

public class Encapsulation_TestEmployee extends Encapsulation_Employee  {
	   public static void main(String[] args)
	    {
	        Encapsulation_Employee obj = new Encapsulation_Employee();
	 
	       
	        obj.setName("vanitha");
	        obj.setSalary(15000);
	        obj.setID(20);
	 
	        
	        System.out.println("Employee's name: " + obj.getName());
	        System.out.println("Employee's salary: " + obj.getSalary());
	        System.out.println("Employee's ID: " + obj.getID());
	 }}
