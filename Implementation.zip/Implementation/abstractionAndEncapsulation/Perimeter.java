package abstractionAndEncapsulation;

abstract class Perimeter{
	public abstract	double calculatePerimeter(double a);

}

class Circle1 extends Perimeter{

	@Override
	public double calculatePerimeter(double r) {
		double a=r;
		double circumference= 2*3.14*a;
		return circumference;
	}
}

class Square1 extends Perimeter{

	@Override
	public double calculatePerimeter(double a) {
		double side=a;
		double perimeter= 4*side;
		return perimeter;
	}

}

