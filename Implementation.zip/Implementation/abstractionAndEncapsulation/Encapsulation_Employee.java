package abstractionAndEncapsulation;

public class Encapsulation_Employee {
	    
	    private String empName;
	    private int empID;
	    private int empSalary;
	 
	    
	    public int getSalary()     {
	             return empSalary;   }
	 
	    
	    public String getName() {
	           return empName;   }
	 
	    public int getID() { 
	             return empID; }
	 
	    
	    public void setSalary(int newSalary) { 
	             empSalary = newSalary; }
	 
	    
	    public void setName(String newName)
	    {
	        empName = newName;
	    }
	 
	    
	    public void setID(int newID) { empID = newID; }
	}
