package abstractionAndEncapsulation;

public abstract class Abstraction_shape {
	abstract double area();
}
	class rectangle extends Abstraction_shape
	{
		double length=10;
		double breadth=12;
		@Override
		double area() {
			return length*breadth;
		}
	}
	class Circle extends Abstraction_shape{
		double r=9;
		@Override
		double area() {
			return 3.14*r*r;
		}
	}

