package abstractionAndEncapsulation;

public  class Abstract_main{
		 public static void main(String[] args) {
			rectangle s= new rectangle();
			System.out.println("area of rectangle = "+s.area());
			Circle c= new Circle();
			System.out.println("area of Circle = "+c.area());
		}


	}
