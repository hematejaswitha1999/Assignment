package abstractionAndEncapsulation;

public class Perimeter_main {

		public static void main(String[] args) {
			Square1 sq = new Square1();
			System.out.println("perimeter of square = "+sq.calculatePerimeter(8.5));

			Circle1 cs= new Circle1();
			System.out.println("circumference of Circle = "+ cs.calculatePerimeter(4.5));

		}

	}

